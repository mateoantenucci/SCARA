# Del SCARA de SolidWorks al proyecto de Webots

> Actualización 14/10/2026: el alcance se amplió a gemelo digital con TCP/IP, dinámica y fallas. La planificación vigente está en [PLAN_GEMELO_DIGITAL.md](PLAN_GEMELO_DIGITAL.md). Esta guía conserva el procedimiento de conversión CAD; sus referencias a dinámica opcional y a alcance aún no definido corresponden a la conversación inicial.

Fecha de revisión: 29 de septiembre de 2026. Webots instalado en este equipo: R2025a.

Alcance confirmado por el grupo: la entrega completa todavía no está definida; empezar por **modelo y movimiento**. El primer hito es la geometría y los cuatro ejes articulados. La validación dinámica y el controlador de trayectorias quedan para cuando la cátedra precise sus requisitos.

La recomendación es reutilizar el CAD del profesor, obtener mallas por cuerpo móvil y construir una cadena articulada en Webots. No es necesario redibujar todas las piezas ni que los cuatro integrantes instalen SolidWorks. El primer objetivo debería ser un modelo que se vea correctamente y mueva sus cuatro articulaciones; la fidelidad dinámica y el control de trayectorias se incorporan después.

Esta guía distingue datos de los archivos, decisiones recomendadas y datos pendientes. No se abrió todavía el CAD con un traductor compatible: la integridad de los ensambles, sus relaciones de posición y sus propiedades físicas siguen pendientes de validación.

## 1. Qué hay en la carpeta

Inventario inicial, antes de agregar esta documentación:

| Material | Cantidad | Uso |
| --- | ---: | --- |
| `.SLDPRT` | 50 | Geometría de piezas de SolidWorks. |
| `.SLDASM` | 10 | Ensambles y posiciones de componentes; requieren resolver sus referencias. |
| `.SLDDRW` | 44 | Dibujos técnicos nativos de SolidWorks. |
| PDF | 45 | Documento principal y 44 planos exportados. |
| STL | 3 | Mallas ya utilizables: dos carreteles A y una polea. |
| G-code | 1 | Instrucciones de fabricación por impresión 3D; no es el modelo para Webots. |
| Fotografías y renders | 20 | Referencia visual del montaje e inspiración. |

No se encontraron archivos `.wbt`, `.proto`, `.urdf`, STEP ni código de control en la entrega original.

Fuente de especificaciones: [00-SCARA-Master.pdf](../00-SCARA-Master.pdf), versión del documento 2026-05-02. Los archivos de [Modelos3D](../Modelos3D) y los [renders](../fotografias) permiten complementar el documento.

Los nombres sugieren familias: `0-` base/torre, `A-` brazo, `B-` antebrazo, `R-` rotación de muñeca y `Z-` mecanismo vertical. Es una orientación para investigar; la pertenencia definitiva se verifica abriendo el ensamble.

## 2. Qué SCARA hay que representar

El documento, páginas 5-6, define una cadena serie **R-R-R-P**. En este proyecto J3 es el giro y J4 el desplazamiento vertical; algunos ejemplos industriales usan la numeración inversa.

| Elemento | Dato del documento | Cómo usarlo inicialmente |
| --- | --- | --- |
| Torre/base | Altura cinemática nominal: 200 mm | Referencia provisional de la altura del primer eje. Medir en el conjunto. |
| Brazo | 250 mm entre ejes | Distancia J1-J2: 0,250 m, pendiente de verificar en CAD. |
| Antebrazo | 250 mm entre ejes | Distancia J2-J3: 0,250 m, pendiente de verificar en CAD. |
| J1 | Rotacional vertical, excursión 270° | `HingeJoint` con motor rotacional. |
| J2 | Rotacional vertical, excursión 270° | `HingeJoint` con motor rotacional. |
| J3 | Rotacional vertical, excursión 300° | `HingeJoint` con motor rotacional. |
| J4 | Prismático vertical, excursión 120 mm | `SliderJoint` con motor lineal. |
| Herramienta | El proyecto se describe sin efector | Representar primero el soporte o una referencia de herramienta. |

El radio nominal máximo es 0,500 m. Ese círculo es una envolvente geométrica, no una garantía de que cualquier punto interior sea alcanzable: también importan límites articulares, colisiones y singularidades.

**Medir entre ejes, no entre extremos de caños.** Por ejemplo, [A-Brazo.PDF](../Modelos3D/A-Brazo.PDF) muestra un caño de 300 mm y separación entre ejes de 250 mm. [B-Antebrazo.PDF](../Modelos3D/B-Antebrazo.PDF) muestra un caño de 237 mm; eso por sí solo no determina la separación entre los ejes del conjunto armado. Los soportes pueden añadir desplazamientos.

## 3. Qué significa importar a Webots

Hay tres trabajos distintos:

1. **Geometría visual:** reutilizar superficies exportadas del CAD.
2. **Modelo articulado:** definir qué cuerpos se mueven juntos y dónde están sus articulaciones.
3. **Comportamiento:** establecer colisiones, propiedades físicas, actuadores y luego control.

Un STL contiene triángulos. No define por sí solo una articulación, sus límites, masa, sensor o controlador. Cambiar la extensión de un `.SLDPRT` a `.stl` tampoco convierte el archivo.

Webots R2025a acepta `.stl`, `.obj` y `.dae` en `Mesh`. No lee los formatos nativos de SolidWorks ni STEP mediante ese nodo. `CadShape` sirve para OBJ/DAE con apariencias. Por eso STEP es un formato intermedio de CAD y STL/OBJ es el formato práctico de geometría para el simulador. Fuentes: [Mesh R2025a](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/mesh.md), [CadShape R2025a](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/cadshape.md).

El flujo recomendado es:

```text
SLDPRT + SLDASM + planos
          |
          v
Onshape, o SolidWorks del profesor/compañero/laboratorio
          |
          +--> STEP: copia CAD para medir o editar en FreeCAD
          |
          +--> STL/OBJ separados por cuerpo móvil
                          |
                          v
Webots: Robot + Solids + Joints + motores + colisiones
                          |
                          v
SCARA.proto + scara.wbt + mallas + controlador posterior
```

No exportar todo el robot como una sola malla si se pretende articularlo. Sí se pueden agrupar las piezas que pertenecen al mismo cuerpo rígido.

## 4. Herramientas para el grupo

| Herramienta | Función recomendada | Límite relevante |
| --- | --- | --- |
| Webots | Construir y ejecutar la simulación en los tres sistemas | Usar la misma versión y revisar requisitos del equipo. |
| Onshape | Importar piezas/ensambles SolidWorks desde navegador, medir y exportar | Traducción a validar; los ensambles necesitan dependencias. Revisar privacidad del plan. |
| FreeCAD | Trabajar localmente con STEP, medir, modificar y exportar mallas | La importación directa del formato nativo SolidWorks no es la ruta estándar documentada. |
| SolidWorks de escritorio | Abrir originales con mayor fidelidad y exportarlos | Sus requisitos oficiales actuales indican Windows y CPU x86_64. Puede bastar una sola máquina del grupo o laboratorio. |
| eDrawings para Mac | Visualizar piezas y ensambles nativos | No sustituye al CAD de edición; su ayuda Mac lista guardar STL entre funciones no admitidas. |
| Blender | Opcional: ajustar origen, materiales o complejidad de mallas | No lo usaría como primer traductor de los archivos nativos SolidWorks. |

Dos rutas principales:

**A. Sin depender de una instalación de SolidWorks:** probar primero una pieza en Onshape; si traduce bien, importar un ensamble con sus dependencias y exportar STEP y STL/OBJ. Pueden trabajar desde Mac, Linux y Windows.

**B. Con conversión hecha por el profesor o una sola máquina:** pedir STEP y mallas separadas por cuerpo móvil. Usar FreeCAD en Mac/Linux para consultar o modificar el CAD neutral y Webots para construir la simulación.

No comprar una licencia ni configurar una máquina virtual para empezar. Una exportación desde la cátedra o la prueba de Onshape resuelve primero la necesidad real. Para una eventual virtualización, comprobar hardware, versión y licencia; que una configuración arranque no garantiza soporte oficial.

Onshape Free publica los documentos. Para uso académico, revisar la opción Education y la privacidad concreta del documento antes de cargar el material. Un archivo importado puede conservar la forma sin reconstruir el historial paramétrico original ni las relaciones mecánicas listas para Webots.

Detalles y fuentes oficiales: [FUENTES_CAD_WEBOTS.md](FUENTES_CAD_WEBOTS.md).

## 5. Primer piloto: una pieza y un subensamble

### Pieza

1. Importar `A-Brazo.SLDPRT` en un documento de Onshape apropiado para el proyecto, o abrir el STEP equivalente en FreeCAD.
2. Comprobar que se ve como el plano y medir separación entre ejes y sección del caño.
3. Exportar STEP para conservar CAD intercambiable y STL para la prueba visual.
4. Registrar unidades de exportación, origen y orientación.
5. Insertar la malla en un mundo de Webots mediante `Shape` + `Mesh`; comprobar tamaño con una referencia de 0,250 m.

### Subensamble

1. Probar `A-EnsambleBrazo.SLDASM` con sus piezas y subensambles referenciados.
2. Para Onshape, empaquetar el ensamble y todas sus dependencias en ZIP. Su ayuda indica buscar un archivo de ensamble con el mismo nombre del ZIP: `A-EnsambleBrazo.zip` debe contener `A-EnsambleBrazo.SLDASM`.
3. Si se dispone de SolidWorks, usar **Pack and Go** para recopilar referencias; enviar solo el `.SLDASM` no alcanza.
4. Revisar componentes ausentes, configuraciones, orientación y posiciones. Después identificar el ensamble general correcto con el profesor.

`0-EnsambleColision.SLDASM` merece revisión como posible conjunto de comprobación, pero no se ha confirmado que sea el ensamble maestro. El nombre no prueba su contenido.

Hay una referencia textual a `2GT_60Teet_40Bore.SLDPRT` dentro de `R-EnsambleRotacion.SLDASM`; ese nombre no está entre los archivos entregados. Sí existe `2GT_80Teet_40Bore.SLDPRT`. Puede tratarse de una referencia antigua, suprimida o pendiente: comprobarlo al abrir el ensamble, sin sustituir piezas automáticamente. Otras referencias internas tienen nombres antiguos de ensambles. La lectura de nombres en binarios es solo un indicio, no una auditoría completa de dependencias.

### Escala de los STL que ya existen

Los tres STL existentes son binarios y contienen aproximadamente 6.300-6.700 triángulos cada uno. Sus dimensiones numéricas principales son 55,1, 70 y 74 unidades, coherentes con milímetros de estas piezas. Esa correspondencia es una inferencia que hay que verificar contra CAD/plano: STL no codifica una unidad física fiable.

Si la exportación está en milímetros, aplicar **una sola vez** el factor `0.001` al importar para trabajar en metros. Si ya se exportó en metros, no volver a escalar. También revisar el origen: estos STL no están todos centrados en el eje de su pieza.

## 6. Construcción del modelo en Webots

Primero hacer una versión simple con cajas/cilindros y longitudes nominales. Mientras otro integrante convierte CAD, ya se pueden comprobar ejes, signos y la jerarquía. Reemplazar las formas visuales por mallas una vez que esa estructura funcione.

La estructura prevista es:

```text
Robot: base + torre fija
└── J1: HingeJoint
    └── Solid: brazo
        └── J2: HingeJoint
            └── Solid: antebrazo
                └── J3: HingeJoint
                    └── Solid: conjunto Z que gira
                        └── J4: SliderJoint
                            └── Solid: pistón + soporte de herramienta
```

Esto implica una base y cuatro cuerpos móviles principales. Las piezas atornilladas entre sí pueden aportar varias mallas al mismo `Solid`. Las transmisiones internas que giran respecto de esos cuerpos necesitan tratamiento propio si más adelante se quiere animarlas o simularlas.

Recomendaciones de implementación:

- Adoptar explícitamente Z vertical y XY horizontal para este proyecto, registrando la conversión desde las coordenadas CAD.
- En cada giro, definir `axis` y `anchor` en el sistema local correcto, haciendo coincidir el eje con los centros mecánicos. Fuente: [HingeJointParameters R2025a](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/hingejointparameters.md).
- Añadir tres `RotationalMotor` y un `LinearMotor`, con nombres estables como `j1_motor` a `j4_motor`.
- Añadir `PositionSensor` para medir posiciones en la simulación. El robot físico se documenta sin encoders: estas mediciones son instrumentación del simulador, no evidencia de sensores reales. Fuente: [PositionSensor](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/positionsensor.md).
- Separar malla visual y `boundingObject`. Usar cajas/cilindros sencillos para colisiones; conservar el CAD detallado como apariencia.
- Mantener la base fija y usar `Physics` en los cuerpos móviles cuando se incorpore dinámica. Registrar masa, centro de masa y tensor de inercia en el sistema de cada cuerpo. Fuentes: [Physics](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/physics.md), [Solid](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/solid.md).
- Si se usan masas estimadas para empezar, etiquetarlas como provisionales. Una malla hueca de aluminio o una pieza PLA con relleno no deben tratarse automáticamente como volumen macizo del mismo material.
- Evitar inicialmente la simulación de dientes, correas y rosca ACME. Un motor ideal de articulación y un eje prismático representan la cinemática útil; la transmisión se añade cuando lo exija el alcance.

Los recorridos del documento son amplitudes totales; no determinan por sí solos los mínimos, máximos ni el cero mecánico. Para un prototipo se podrían adoptar J1/J2 = ±135°, J3 = ±150° y J4 = 0-0,120 m, siempre etiquetando esa convención como provisional. Las posiciones angulares de los motores Webots se expresan en radianes; las lineales, en metros. Fuente: [Motor](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/motor.md).

Estructura de proyecto recomendada, aún por crear:

```text
webots/
  worlds/scara.wbt
  protos/SCARA.proto
  protos/meshes/
  controllers/scara_demo/scara_demo.py
docs/
  GUIA_PROYECTO_SCARA_WEBOTS.md
  FUENTES_CAD_WEBOTS.md
```

El `.wbt` contiene el mundo; el `.proto` reutiliza el robot. La entrega debe incluir las mallas y, cuando exista, el controlador: compartir solamente el `.wbt` puede dejar referencias rotas. Utilizar rutas relativas dentro del proyecto. Fuente: [estructura de proyecto y mundo](https://github.com/cyberbotics/webots/blob/R2025a/docs/guide/the-user-interface.md).

## 7. Datos pendientes e inconsistencias

En el documento principal:

- La sección 3.6, Denavit-Hartenberg, está pendiente (página 8).
- Las aceleraciones máximas no están definidas (página 8).
- Varias masas se indican como `??`; no hay un conjunto completo de propiedades dinámicas validado.
- Los modelos de motor están identificados, pero quedan datos eléctricos pendientes y no se aporta una caracterización completa de torque/velocidad para la simulación (página 10).
- El diagrama de conexiones está pendiente (página 15).
- Arquitectura de software, protocolo, firmware y trayectorias están pendientes (página 16).
- Falta definir una herramienta real si la entrega requiere agarrar objetos (página 3).

La tabla de velocidad rotacional de la página 8 escribe `4,44°/s; 266 rpm`, magnitudes que no son equivalentes:

```text
4,44 grados/segundo = 0,74 rpm
266 rpm = 1.596 grados/segundo
1.000 rpm de motor / reducción 4:1 = 250 rpm de salida, idealmente
```

Además, 4,44 aparece en otra tabla como pasos por grado. No copiar ese número a `maxVelocity` sin aclaración. El cálculo de 250 rpm es aritmético y sin carga, no una prestación garantizada. El avance ACME de 8 mm/vuelta produce teóricamente 133,3 mm/s a 1.000 rpm, pero también requiere validación bajo carga.

M1 y M2 están en la base, con ejes concéntricos y transmisión por correa al codo (página 11). Si luego se convierten ángulos articulares en pasos de motores físicos, verificar el acoplamiento y los signos: no asumir que el ángulo relativo J2 coincide sin más con la rotación de M2 dividida por cuatro.

Estas incertidumbres no impiden construir la geometría ni probar cinemática. Sí limitan las conclusiones de dinámica, carga y rendimiento.

## 8. Etapas y criterios de avance

| Etapa | Entregable | Comprobación que permite seguir |
| --- | --- | --- |
| 1. Conversión piloto | Un brazo importado y un subensamble legible | Medidas y posiciones coherentes con planos; referencias resueltas. |
| 2. Estructura articulada | Mundo con base y cuatro articulaciones, geometría simple | Cada eje mueve sus descendientes correctos; los otros ejes conservan su posición relativa. |
| 3. Apariencia CAD | Mallas en sus cuerpos móviles | Escala, orientación y montaje coinciden con renders. |
| 4. Comprobación de movimiento | Pequeño controlador de demostración | Barrer cada eje, verificar sentido, límites y recorrido vertical. |
| 5. Cinemática | Funciones directa/inversa y poses objetivo | Posiciones calculadas y medidas coinciden dentro de una tolerancia acordada. |
| 6. Dinámica, si se exige | Masas, inercias, esfuerzos y límites respaldados | Movimiento estable y parámetros con fuente o estimación documentada. |
| 7. Tarea final | Trayectoria o pick-and-place, informe y proyecto portable | Otro integrante abre y reproduce el resultado desde una copia limpia. |

Para el controlador inicial recomiendo Python si la cátedra no fija otro lenguaje. Basta mandar posiciones articulares y leer resultados; el programa completo de Arduino no es un requisito previo para modelar en Webots.

La cinemática planar nominal del documento es:

```text
x = L1*cos(q1) + L2*cos(q1+q2)
y = L1*sin(q1) + L2*sin(q1+q2)
```

Después de medir el ensamble, sustituir las longitudes nominales si corresponde. Para muñeca y altura hay que definir referencias: con ejes verticales alineados, orientación horizontal = q1+q2+q3 más un offset; z depende del signo elegido para q4 y del offset de herramienta. La inversa debe comprobar alcanzabilidad, límites y las dos configuraciones de codo, además de manejar singularidades.

## 9. Reparto sugerido entre cuatro integrantes

1. **CAD y conversiones:** verificar ensambles, medidas, escala y exportaciones. Si hay una máquina con SolidWorks, usarla para esta tarea puntual.
2. **Modelo Webots:** jerarquía, articulaciones, posiciones, colisiones y empaquetado del robot.
3. **Cinemática y pruebas:** referencias, signos, ecuaciones y comparación con posiciones del simulador.
4. **Demostración y documentación:** controlador de prueba, trayectoria posterior, reproducción en otro sistema y registro de decisiones.

Conviene acordar primero unidades, origen, nombres de articulaciones, pose cero, versión Webots y una tabla única de parámetros. Mantener los originales CAD separados de las exportaciones. Para los archivos de texto, un repositorio compartido facilita integrar trabajo; las mallas grandes pueden guardarse con una estrategia acordada por el grupo.

## 10. Próximas acciones concretas

1. Probar `A-Brazo.SLDPRT` en Onshape con el plan adecuado, o pedir su STEP al profesor.
2. Conseguir el ensamble maestro con dependencias resueltas; pedir Pack and Go si hace falta.
3. Medir centros J1-J2-J3, alturas y posición del conjunto Z. Registrar pose cero y recorridos.
4. Exportar geometría separada para base, brazo, antebrazo, conjunto Z rotativo y pistón.
5. Construir el primer `.wbt` con cuatro articulaciones y confirmar movimiento individual antes de añadir una tarea de manipulación.

Para alinear el alcance con la cátedra, confirmar: si se evalúa solo modelo/cinemática o también dinámica; cuál es el ensamble y configuración de referencia; cómo se definen ceros y topes; cuál es la corrección de la tabla de velocidades; y si se requiere herramienta y una tarea específica.

El primer hito útil es **un SCARA articulado de cuatro ejes que abra en los equipos del grupo y conserve las medidas verificadas**, aunque las primeras formas sean simples y los parámetros dinámicos estén todavía pendientes.
