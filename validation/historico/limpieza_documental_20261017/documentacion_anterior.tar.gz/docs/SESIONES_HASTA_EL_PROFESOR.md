# Sesiones hasta la reunión con el profesor

Plan del 17/10/2026 para llegar al **martes 20 de octubre** con avances comprobados y preguntas concretas. Esta es la ruta de trabajo; las sesiones siguientes todavía no están realizadas.

## Hasta dónde llegamos

| Punto original | Estado actual |
| --- | --- |
| 1. Tres geometrías faltantes | **Resuelto:** recuperamos B-CarretelInf, B-CarretelSup y Z-SoporteEfector. Ya aparecen en el robot. |
| 2. Montaje y autocolisiones | **En curso:** 38 piezas, seis rodamientos simplificados y dos poleas de salida visuales. Se corrigió la tapa de muñeca. Hay controles contra el entorno y de herramienta/carga contra la base; falta cubrir otros choques internos y piezas omitidas. |
| 3. Física fundamentada | **Preparada parcialmente:** propiedades geométricas calculadas y transmisiones nominales identificadas. Masas, materiales, impresión y esfuerzos reales siguen pendientes. |
| 4. Comportamiento y entrega | **Prototipo funcional:** movimiento, interfaz, comunicación provisional y fallas básicas. Faltan protocolo oficial, homing, alcance de otras fallas y ejecución comprobada en Windows/Linux. |

La versión actual aprobó **34 pruebas de software y ensayos de movimiento/contacto en Webots**. Eso valida los casos probados, no un robot completo ni todo su espacio de movimiento.

## Sesiones y cierre de cada una

| Sesión | Trabajo | Qué debe quedar al terminar |
| --- | --- | --- |
| **1. Terminar de revisar el montaje** | Revisar las piezas omitidas: ejes, poleas restantes y mecanismo vertical. Agotar las comprobaciones de colocación y giro que permiten los archivos, especialmente en M3. Agregar solo lo sustentado. | Inventario breve: incorporado, provisional o pendiente, con motivo. Cada pieza revisada queda resuelta hasta donde permiten las fuentes; no se acomoda a ojo para completar el dibujo. |
| **2. Choques y contactos internos** | Revisar los nuevos componentes, mejorar las formas de contacto donde las cajas generan choques falsos y ampliar los casos y recorridos comprobados. | Lista clara de pares y movimientos cubiertos, choques encontrados y rechazos probados. Los contactos internos solo se activan donde el modelo los sostenga; las zonas pendientes quedan explícitas. |
| **3. Física y transmisión** | Reunir los datos disponibles de materiales, impresión y componentes comerciales. Contrastar fichas de los modelos identificados y calcular lo que permitan las transmisiones sustentadas. | Tabla corta con dato, fuente y certeza. Aplicar únicamente propiedades suficientemente respaldadas; separar cálculos nominales de prestaciones reales. Lo desconocido se convierte en una consulta concreta. |
| **4. Comportamiento y fallas** | Repetir movimiento, detención, desconexión, Hall y pérdida de esfuerzo sobre la versión resultante. Revisar cómo adaptar el protocolo y qué necesita el homing. | Demostración estable y fallas acordadas comprobadas. Procedimiento propuesto para buscar la referencia inicial, con sus datos pendientes; reiniciar el ensayo sigue sin equivaler a homing físico. Las fallas adicionales dependen del alcance docente. |
| **5. Portabilidad y reproducción** | Probar desde una copia limpia, revisar dependencias y rutas, y completar instrucciones simples. Ejecutar en Windows/Linux si disponemos de esos entornos. | Paquete reproducible y registro de sistemas efectivamente probados. Si falta un entorno, queda una guía de prueba para otro integrante y la ejecución marcada como pendiente. |
| **6. Preparar la reunión** | Consolidar resultados, quitar preguntas ya resueltas y ordenar las decisiones del profesor. Preparar una demostración breve. | Una página de avances, lista priorizada de dudas y demostración de movimiento, rechazo de choque y una falla. Cada duda indica qué decisión permite destrabar. |

**Distribución sugerida:** sábado 17, sesiones 1–2; domingo 18, sesiones 3–4; lunes 19, sesiones 5–6. El orden de dependencia manda: si una revisión requiere más trabajo, se registra el avance real y se ajusta el reparto.

## Regla para avanzar sin quedarnos esperando

Cada sesión termina con **qué quedó comprobado, qué sigue provisional y qué necesita al profesor**. Una duda externa detiene solo la parte que depende de ella; seguimos con el resto de los puntos. Si aparecen datos nuevos, repetimos las pruebas afectadas antes de dar esa parte por cerrada.

## Qué necesitamos resolver el martes

1. **Diseño vigente:** qué revisión usar y cómo resolver las diferencias de piezas, fijaciones y transmisión.
2. **Física:** materiales e impresión, componentes elegidos y configuración de motores/controladores.
3. **Referencias:** ceros, sentidos, topes, sensores y punto de herramienta.
4. **Contrato docente:** protocolo, homing, fallas exigidas y criterios de aceptación.

La lista detallada está en [Consultas para el profesor](DATOS_PARA_EL_PROFESOR.md). Se depurará durante estas sesiones; todavía no fue enviada. Los avances actuales están en [Montaje](MONTAJE_Y_AUTOCOLISIONES.md) y [Transmisión](TRANSMISION.md).
