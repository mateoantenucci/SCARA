# Cómo llega el giro de los motores al robot

Revisión del 17/10/2026. **Los valores del documento maestro ya están identificados; todavía falta confirmar el montaje definitivo.**

| Motor | Qué mueve | Transmisión indicada en el maestro |
| --- | --- | --- |
| M1 | Brazo | Poleas de 20 y 80 dientes: cuatro vueltas del motor por una de salida. |
| M2 | Antebrazo, desde la base | Reducción 20→80 y luego una correa entre dos poleas de 60 dientes. También interviene el giro del brazo. |
| M3 | Giro de muñeca | Poleas de 20 y 80 dientes: reducción 4:1. |
| M4 | Subida y bajada | Tornillo ACME: avance indicado de 8 mm por vuelta. |

Fuente: [maestro, páginas 10–12](../00-SCARA-Master.pdf#page=10). Son datos de diseño; no certifican velocidad, fuerza disponible ni configuración de los controladores.

## Lo que pudimos comprobar

Agregamos **dos poleas de salida como visuales**: la del eje exterior acompaña al brazo y la del codo al antebrazo. Coinciden los ejes, los diámetros y las zonas de apriete en las colocaciones revisadas. Conservamos su posición y orientación guardadas, todavía provisionales. El robot pasa de 36 a **38 piezas colocadas**.

La polea grande de muñeca tiene **80 dientes en la geometría CAD**. Contamos las ranuras y comprobamos que se repiten uniformemente. El plano suelto dice 60; esa diferencia queda registrada para confirmar la revisión vigente.

Las otras siete geometrías de polea tienen superficies lisas: no permiten contar dientes. Sus nombres y el maestro aportan una referencia, pero no una comprobación geométrica de esa cantidad.

M1 y M2 están en la base y usan ejes concéntricos. Por eso **no alcanza con dividir el giro de M2 por cuatro para obtener el ángulo del codo**: también hay que considerar cuánto giró el brazo.

## Qué falta para usarlo en la simulación

Siguen pendientes otras poleas y varios ejes. Los tres piñones de motor y la polea del eje interior necesitan giros propios respecto de los soportes. En M3, además, hay poco tramo de eje disponible en la colocación guardada y una discrepancia de revisión; falta contrastar ese montaje. La polea grande de muñeca todavía no está incorporada.

Confirmar la revisión, el montaje definitivo, el recorrido de las correas y los sentidos de giro permitirá calcular la relación completa. Los ceros y la configuración de pasos también siguen pendientes.

Por ahora el banco mueve las cuatro articulaciones directamente. Estos datos todavía no cambian sus masas, esfuerzos ni límites de movimiento.

Las dudas para la cátedra están en [Consultas para el profesor](DATOS_PARA_EL_PROFESOR.md). El respaldo queda en [fuentes y páginas](../validation/transmission_sources.json), [montaje de poleas](../validation/pulley_mounts.json) y [conteo geométrico](../validation/pulley_geometry.json). No hace falta leer esos informes para usar el robot.
