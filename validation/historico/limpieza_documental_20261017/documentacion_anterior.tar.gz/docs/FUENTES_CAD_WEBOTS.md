# Fuentes verificadas: de SolidWorks a Webots

Consulta: 29 de septiembre de 2026. Solo fuentes del fabricante o del proyecto. Esta nota verifica herramientas y formatos; no prueba todavía la conversión de los archivos del profesor. No se subió ningún CAD a servicios externos.

## Decisión práctica

Se puede reutilizar la geometría existente sin redibujar cada pieza. El flujo recomendado es obtener un formato CAD neutral para conservar el modelo y una malla por cada conjunto rígido para visualizarlo en Webots. Convertir una pieza no construye por sí solo un robot articulado: después hay que definir la cadena, articulaciones, límites, motores, sensores y propiedades físicas en el simulador.

No hace falta que los cuatro instalen SolidWorks. Para un grupo Mac/Linux/Windows, conviene elegir entre:

1. **Exportación del profesor o del compañero con Windows:** pedir STEP y STL/OBJ por pieza o conjunto rígido. Trabajar luego con FreeCAD y Webots en cada sistema.
2. **Onshape Education:** importar los nativos en el navegador, revisar geometría y ensamblaje, exportar STEP para archivo y STL/OBJ para Webots. Confirmar la cuenta educativa y privacidad del documento antes de cargar material del profesor.

Estas son recomendaciones de flujo, basadas en las capacidades verificadas abajo; ninguna promete conservar automáticamente el historial CAD o todas las restricciones del ensamblaje.

## Webots: qué entra y qué falta

- El nodo `Mesh` de R2025a admite **STL, OBJ y Collada/DAE**. Puede utilizarse para apariencia o colisión. `.sldprt`, `.sldasm` y STEP no figuran como formatos de `Mesh`. Si el archivo contiene varias mallas, normalmente se combinan; conviene exportar por conjunto rígido que deba moverse independientemente. Usar rutas relativas permite compartir el proyecto entre sistemas. [Documentación Mesh de R2025a](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/mesh.md).
- `CadShape` importa **OBJ o DAE**, incluyendo materiales y referencias a texturas. Para una primera versión, STL más una apariencia definida en Webots reduce dependencias; OBJ resulta útil si se quieren conservar materiales. [Documentación CadShape de R2025a](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/cadshape.md).
- La herramienta oficial **urdf2webots** convierte un URDF a un PROTO o a texto de un nodo Robot. Es una ruta opcional para una descripción robótica ya preparada, no un lector directo de nativos SolidWorks. [Repositorio urdf2webots](https://github.com/cyberbotics/urdf2webots).
- La física tiene campos propios para masa, centro de masa e inercia. La descripción visual importada no sustituye esta configuración. [Documentación Physics de R2025a](https://github.com/cyberbotics/webots/blob/R2025a/docs/reference/physics.md).

La última release estable identificada por el enlace oficial `releases/latest` en esta consulta es **R2025a**. Tiene instaladores para Windows, Linux x86-64 y macOS Apple Silicon/Intel. Los requisitos de esa release listan Ubuntu 22.04/24.04, Windows 10/11 de 64 bits y macOS 12/13/14. Para otras versiones de macOS hay que comprobar el arranque y un mundo simple en cada máquina; no extrapolar soporte oficial. La rama `master` contiene requisitos futuros diferentes, por eso aquí se utiliza el tag de la release. [Release R2025a](https://github.com/cyberbotics/webots/releases/tag/R2025a), [requisitos de R2025a](https://github.com/cyberbotics/webots/blob/R2025a/docs/guide/system-requirements.md).

## Onshape: alternativa común desde el navegador

Onshape funciona en dispositivos con navegador y dispone de colaboración simultánea. La documentación actual admite piezas SolidWorks `.sldprt` de 1999 a 2026. Puede exportar piezas y ensamblajes a STEP, STL y OBJ. La documentación consultada incluye ahora **URDF para ensamblajes**: se puede explorar cuando las articulaciones estén preparadas, pero no se ha verificado aquí qué restricciones de este ensamblaje se traducirían. [Plataforma y planes](https://www.onshape.com/en/pricing), [formatos admitidos](https://cad.onshape.com/help/Content/File/supported_file_formats.htm).

Para importar un ensamblaje SolidWorks se debe incluir el `.sldasm` y sus dependencias. La ayuda recomienda preparar **Pack and Go**, aplanar a una carpeta y crear un ZIP con el mismo nombre que el ensamblaje principal, sin caracteres especiales. Si hay configuraciones/componentes ligeros, resolverlos y guardar/reconstruir antes de exportar. Si el grupo solo posee piezas sueltas, se pueden importar individualmente; recuperar el ensamblaje requerirá colocación y relaciones. [Importación de archivos y preparación de SolidWorks](https://cad.onshape.com/help/Content/Document/importing_files.htm).

Al exportar:

- STL permite elegir unidades y malla binaria o ASCII. Para Webots conviene acordar **metros** y comprobar una dimensión conocida al importar.
- OBJ se descarga en un ZIP que contiene `.obj` y `.mtl`; la ayuda indica que OBJ utiliza metros.
- Se puede exportar STL por archivos individuales, y ajustar resolución/tolerancias. Evitar exportar todo el brazo en una sola malla si sus eslabones deben moverse.
- Los archivos exportados no contienen el historial paramétrico ni las operaciones del documento.
- URDF solo está disponible al exportar un Assembly; permite seleccionar la geometría asociada. Para la ruta Webots, preferir STL/OBJ admitidos por `Mesh`, y validar después la conversión.

[Exportación de archivos](https://cad.onshape.com/help/Content/File/exporting_files.htm).

### Education y Free no son lo mismo

**Free** es para uso no comercial y todos los documentos que crea son públicos. La cuenta **Student/Education** es gratuita para uso académico elegible. La ayuda Student describe un entorno equivalente a Standard y habla explícitamente de documentos privados, que siguen privados al bajar a Free pero pasan a ser de solo lectura. Los términos distinguen usuarios Education de usuarios Free. Por ello la recomendación es solicitar **Education**, comprobar la suscripción y la visibilidad del documento, y no crear el proyecto del profesor en Free por accidente. [Planes](https://www.onshape.com/en/pricing), [Student](https://cad.onshape.com/help/Content/Plans/managing_your_onshape_student_subscription.htm), [términos](https://www.onshape.com/en/legal/terms-of-use).

Hay una ambigüedad en la web comercial: la FAQ de inscripción Education usa la frase general de que los datos privados requieren plan pago, mientras la ayuda Student y los términos describen documentos privados académicos. La documentación de cuenta es más específica, pero corresponde verificar lo que ofrece la cuenta real antes de subir CAD. [Inscripción Education](https://www.onshape.com/en/education/sign-up).

## FreeCAD: opción local una vez obtenido STEP

FreeCAD tiene descargas para Windows, Mac Apple Silicon/Intel y Linux. Importa STEP y exporta STL/OBJ; sirve para inspeccionar, medir, simplificar o completar geometría neutral localmente. [Descargas](https://www.freecad.org/downloads), [funciones](https://www.freecad.org/features.php).

La tabla oficial de formatos incluye STEP/IGES/BREP y mallas, pero no enumera `.sldprt` ni `.sldasm`. **No tomar FreeCAD instalado sin complementos como conversor directo de esos nativos**; para este proyecto usar la ruta SolidWorks/Onshape → STEP → FreeCAD → STL/OBJ. Esta conclusión se basa en la lista de formatos, no en una prueba con los CAD del profesor. [Tabla oficial Import Export](https://github.com/FreeCAD/FreeCAD-documentation/blob/main/wiki/Import_Export.md).

## eDrawings para Mac: sirve para mirar

El visor gratuito puede abrir archivos SolidWorks, incluidos `.sldprt`, `.sldasm` y `.slddrw`; es útil para revisar el material sin el CAD completo. Las posibilidades de medir dependen del modo de publicación y licencia que guardó el archivo. [FAQ eDrawings, sección Mac](https://www.edrawingsviewer.com/frequently-asked-questions).

La ayuda específica de **eDrawings Mac 2025 enumera Guardar como STL entre las funciones no compatibles**. Por eso no se recomienda como ruta de conversión a Webots. La página genérica de guardar archivos puede resultar ambigua: debe prevalecer la lista específica de limitaciones Mac. [Ayuda eDrawings para Macintosh](https://help.solidworks.com/2025/spanish/edrawings/c_eDrawings_for_Macintosh.htm).

## SolidWorks y Fusion: cuándo convienen

SolidWorks de escritorio tiene requisitos Windows y CPU x86-64. La existencia de eDrawings Mac no implica que el CAD completo esté disponible nativamente en macOS. La matriz de virtualización incluye Parallels, pero la página no prueba compatibilidad de cada Mac Apple Silicon, Windows ARM, licencia estudiantil y función; no asumir que esa ruta va a funcionar. Para una conversión puntual, una máquina Windows de un compañero o de la facultad es más directa. [Requisitos de SolidWorks](https://www.solidworks.com/support/system-requirements).

**Autodesk Fusion** es una alternativa si ya tienen acceso educativo verificado y una máquina compatible. La lista general admite `.sldprt`/`.sldasm` hasta SolidWorks 2025, pero no conserva toda la información del programa original. La lista de formatos de **Personal Use** es más limitada y no enumera los nativos SolidWorks: no confundir licencia personal gratuita con Education. [Formatos Fusion](https://help.autodesk.com/view/fusion360/ENU/?caas=caas%2Fsfdcarticles%2Fsfdcarticles%2FFile-formats-supported-by-Fusion-360.html).

Fusion de escritorio soporta Windows/macOS y no se instala directamente en Linux. Existe acceso mediante navegador condicionado a licencia comercial o Education verificada; hay que probar disponibilidad y funciones necesarias antes de adoptarlo para todo el grupo. [Requisitos Fusion](https://help.autodesk.com/view/fusion360/ENU/?caas=caas%2Fsfdcarticles%2Fsfdcarticles%2FSystem-requirements-for-Autodesk-Fusion-360.html), [Linux](https://help.autodesk.com/view/fusion360/ENU/?caas=caas%2Fsfdcarticles%2Fsfdcarticles%2FIs-there-any-way-to-install-Fusion-360-in-Linux.html).

## Lo que sigue pendiente de comprobar con los archivos reales

- Versión de SolidWorks que los guardó; dependencias completas del ensamblaje y configuraciones necesarias.
- Qué piezas deben agruparse en cada cuerpo rígido, y qué elementos se mueven entre sí.
- Resultado de una importación de prueba: piezas faltantes, orientación, escala y posición relativa.
- Ejes y orígenes de articulaciones, límites mecánicos, carreras, masas e inercias disponibles.
- Compatibilidad de la misma release Webots en las cuatro máquinas.
- Alcance académico del controlador, tarea del robot y criterio de aprobación de la materia.

La prueba inicial propuesta es convertir una pieza representativa, importarla en un mundo Webots y contrastar una cota conocida. Después convertir un conjunto de dos eslabones y validar una articulación, antes de procesar todo el ensamblaje.
